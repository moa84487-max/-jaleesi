// Run after `npx cap add android`: copies icons/tones, adds permissions and release signing.
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..'),app=path.join(root,'android','app');
function cp(a,b){fs.mkdirSync(b,{recursive:true});for(const f of fs.readdirSync(a)){const s=path.join(a,f),d=path.join(b,f);fs.statSync(s).isDirectory()?cp(s,d):fs.copyFileSync(s,d)}}
cp(path.join(root,'resources','res'),path.join(app,'src','main','res'));
// manifest permissions
const mp=path.join(app,'src','main','AndroidManifest.xml');let m=fs.readFileSync(mp,'utf8');
const perms=['VIBRATE','POST_NOTIFICATIONS','SCHEDULE_EXACT_ALARM','RECEIVE_BOOT_COMPLETED','WAKE_LOCK'];
let add='';for(const p of perms){if(!m.includes('android.permission.'+p+'"'))add+='    <uses-permission android:name="android.permission.'+p+'" />\n'}
m=m.replace('</manifest>',add+'</manifest>');fs.writeFileSync(mp,m);
// signing + version
const gp=path.join(app,'build.gradle');let g=fs.readFileSync(gp,'utf8');
const vc=process.env.VERSION_CODE||'1',vn=process.env.VERSION_NAME||'1.0';
g=g.replace(/versionCode \d+/,'versionCode '+vc).replace(/versionName "[^"]*"/,'versionName "'+vn+'"');
const sign=`    signingConfigs {
        release {
            storeFile file("../../jalesi.keystore")
            storePassword System.getenv("JALESI_KS_PASS") ?: ""
            keyAlias "jalesi"
            keyPassword System.getenv("JALESI_KS_PASS") ?: ""
        }
    }
`;
if(!g.includes('signingConfigs')){g=g.replace('    buildTypes {',sign+'    buildTypes {');g=g.replace('        release {\n','        release {\n            signingConfig signingConfigs.release\n')}
fs.writeFileSync(gp,g);
console.log('patched');
